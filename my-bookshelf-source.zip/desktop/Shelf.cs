using System;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using System.Drawing;

public class Book {
    public string id, title, folder, url, status;
    public int pages, searchable;
    public string tags="", note="", category="待分类";
}
public class EntryEdit { public string title="", tags="", note="", category=""; public bool removed; }
public class Shelf : Form {
    readonly string home;
    readonly TextBox query = new TextBox();
    readonly ComboBox folders = new ComboBox(), scope = new ComboBox();
    readonly ListView results = new ListView();
    readonly Label status = new Label();
    readonly Button refresh = new Button();
    readonly Button cancelRemoval = new Button();
    readonly Button ask = new Button();
    readonly Button locate = new Button();
    string sessionKey=Environment.GetEnvironmentVariable("DEEPSEEK_API_KEY")??"";
    readonly Button add = new Button(), edit = new Button(), remove = new Button(), open = new Button();
    readonly ComboBox section = new ComboBox();
    readonly ComboBox categories=new ComboBox{Width=155,DropDownStyle=ComboBoxStyle.DropDownList,AccessibleName="馆藏分类"};
    readonly Label heading = new Label();
    readonly Label summary = new Label();
    readonly System.Windows.Forms.Timer debounce = new System.Windows.Forms.Timer { Interval=350 };
    readonly System.Collections.Concurrent.ConcurrentDictionary<string,string[]> textCache=new System.Collections.Concurrent.ConcurrentDictionary<string,string[]>();
    Dictionary<string,EntryEdit> edits;
    Book[] books;
    CancellationTokenSource search;
    bool loading, updating, searching;
    static JavaScriptSerializer Json() { return new JavaScriptSerializer { MaxJsonLength = int.MaxValue }; }
    static readonly Regex gaps = new Regex(@"(?<=[\u3400-\u9fff])\s+(?=[\u3400-\u9fff])", RegexOptions.Compiled);
    public Shelf(string dir) {
        home=dir; Text="我的书架"; Font=new Font("Microsoft YaHei UI",10);
        Icon=Icon.ExtractAssociatedIcon(Application.ExecutablePath);
        BackColor=Color.FromArgb(248,247,242); ForeColor=Color.FromArgb(32,53,47);
        Size=new Size(1160,760); MinimumSize=new Size(860,520); StartPosition=FormStartPosition.CenterScreen;
        var header=new Panel { Dock=DockStyle.Top,Height=87,BackColor=Color.FromArgb(32,66,56) };
        heading.Text="我的书架";heading.Font=new Font("SimSun",26,FontStyle.Bold);
        heading.ForeColor=Color.White;heading.AutoSize=true;heading.Location=new Point(65,20);header.Controls.Add(heading);
        header.Paint+=(s,e)=>{
            using(var pen=new Pen(Color.FromArgb(225,210,163),2)){
                e.Graphics.DrawRectangle(pen,24,26,7,27);e.Graphics.DrawRectangle(pen,34,24,7,29);
                e.Graphics.DrawLine(pen,45,25,53,52);e.Graphics.DrawLine(pen,21,56,56,56);
            }
        };
        summary.AutoSize=false;summary.Width=260;summary.Dock=DockStyle.Right;
        summary.TextAlign=ContentAlignment.MiddleRight;summary.Padding=new Padding(0,0,25,0);
        summary.ForeColor=Color.FromArgb(223,228,204);header.Controls.Add(summary);
        var controls=new FlowLayoutPanel {Dock=DockStyle.Top,AutoSize=true,Padding=new Padding(18,10,10,5)};
        var actions=new FlowLayoutPanel {Dock=DockStyle.Top,AutoSize=true,Padding=new Padding(18,0,10,9)};
        query.Width=235;query.AccessibleName="搜索书名、标签、笔记或正文";
        folders.Width=170;scope.Width=120;section.Width=110;
        folders.DropDownStyle=scope.DropDownStyle=section.DropDownStyle=ComboBoxStyle.DropDownList;
        scope.Items.AddRange(new object[]{"含正文","仅书目信息"});scope.SelectedIndex=0;
        section.Items.AddRange(new object[]{"全部馆藏","已移除"});section.SelectedIndex=0;
        controls.Controls.AddRange(new Control[]{section,categories, new Label {Text="搜索",AutoSize=true,Margin=new Padding(12,6,2,0)},query,scope,folders});
        foreach(var pair in new[]{Tuple.Create(add,"＋ 添加 PDF"),Tuple.Create(open,"阅读"),Tuple.Create(ask,"问 DeepSeek"),Tuple.Create(edit,"编辑资料"),Tuple.Create(locate,"重新定位"),Tuple.Create(remove,"移出书架"),Tuple.Create(cancelRemoval,"取消"),Tuple.Create(refresh,"扫描更新")}){
            var button=pair.Item1;button.Text=pair.Item2;button.AutoSize=true;button.FlatStyle=FlatStyle.Flat;
            button.FlatAppearance.BorderColor=Color.FromArgb(193,203,192);button.BackColor=Color.White;
            button.Padding=new Padding(8,2,8,2);actions.Controls.Add(button);
        }
        add.BackColor=Color.FromArgb(41,94,73);add.ForeColor=Color.White;
        results.Dock=DockStyle.Fill; results.View=View.Details; results.FullRowSelect=true; results.HideSelection=false;
        results.BorderStyle=BorderStyle.None;results.BackColor=Color.FromArgb(255,254,250);results.MultiSelect=true;
        cancelRemoval.Click+=(s,e)=>EndRemoval();
        locate.Click+=(s,e)=>{
            var book=Selected();if(book==null)return;
            using(var picker=new OpenFileDialog{Title="选择这份 PDF 的新位置",Filter="PDF 文档 (*.pdf)|*.pdf"})
                if(picker.ShowDialog(this)==DialogResult.OK)UpdateBooks(null,book.id,picker.FileName);
        };
        ask.Click+=(s,e)=>{
            var book=Selected();if(book==null)return;
            int page;int.TryParse(results.SelectedItems[0].SubItems[1].Text,out page);
            try{
                using(var dialog=new ReadingQuestion(book.title,book.searchable>0?Pages(home,book):new string[book.pages],page,sessionKey,Path.Combine(home,"chats",book.id+".json"))){
                    dialog.ShowDialog(this);sessionKey=dialog.ApiKey;
                }
            }catch(Exception ex){MessageBox.Show(this,ex.Message,"打开阅读问答失败");}
        };
        results.Columns.Add("书名",350);results.Columns.Add("页码",64);results.Columns.Add("正文摘录 / 状态",310);results.Columns.Add("文件夹",170);results.Columns.Add("标签",150);
        var spacing=new ImageList {ImageSize=new Size(1,32)};results.SmallImageList=spacing;
        status.Dock=DockStyle.Bottom;status.Height=38;status.Padding=new Padding(20,7,0,0);
        var content=new Panel{Dock=DockStyle.Fill,Padding=new Padding(20,0,20,0)};content.Controls.Add(results);
        Controls.Add(content);Controls.Add(status);Controls.Add(actions);Controls.Add(controls);Controls.Add(header);
        add.Click+=(s,e)=>AddBooks();edit.Click+=(s,e)=>EditSelected();remove.Click+=(s,e)=>RemoveSelected();open.Click+=(s,e)=>OpenSelected();
        query.TextChanged+=(s,e)=>{debounce.Stop();if(search!=null)search.Cancel();debounce.Start();};
        debounce.Tick+=(s,e)=>{debounce.Stop();FindBooks();};
        query.KeyDown+=(s,e)=>{if(e.KeyCode==Keys.Enter){e.SuppressKeyPress=true;debounce.Stop();FindBooks();}};
        KeyPreview=true;KeyDown+=(s,e)=>{if(e.Control && e.KeyCode==Keys.F){query.Focus();query.SelectAll();e.SuppressKeyPress=true;}};
        results.SelectedIndexChanged+=(s,e)=>SyncActions();
        results.ItemChecked+=(s,e)=>{if(results.IsHandleCreated)BeginInvoke((Action)SyncActions);};
        folders.SelectedIndexChanged+=(s,e)=>FindBooks();section.SelectedIndexChanged+=(s,e)=>{FindBooks();SyncActions();};
        categories.SelectedIndexChanged+=(s,e)=>FindBooks();
        scope.SelectedIndexChanged+=(s,e)=>FindBooks();refresh.Click+=(s,e)=>UpdateBooks(null);
        SyncActions();
        results.DoubleClick+=(s,e)=>OpenSelected();
        results.KeyDown+=(s,e)=>{if(e.KeyCode==Keys.Enter){e.SuppressKeyPress=true;OpenSelected();}};
        FormClosing+=(s,e)=>{if(updating){e.Cancel=true;status.Text="正在更新，完成后即可关闭。";}else if(search!=null) search.Cancel();};
        Shown+=(s,e)=>Reload();
    }
    void Reload(){
        loading=true;
        string file=File.ReadAllText(Path.Combine(home,"index","catalog.js"));
        books=Json().Deserialize<Book[]>(file.Substring("window.books=".Length));
        Dictionary<string,string> defaults;
        using(var reader=new StreamReader(typeof(Shelf).Assembly.GetManifestResourceStream("categories")))
            defaults=Json().Deserialize<Dictionary<string,string>>(reader.ReadToEnd());
        string metadata=Path.Combine(home,"annotations.json");
        edits=File.Exists(metadata)?Json().Deserialize<Dictionary<string,EntryEdit>>(File.ReadAllText(metadata)):new Dictionary<string,EntryEdit>();
        foreach(var b in books){
            string name;if(defaults.TryGetValue(b.id,out name))b.category=name;
            EntryEdit value;if(!edits.TryGetValue(b.id,out value))continue;
            if(!String.IsNullOrWhiteSpace(value.category))b.category=value.category;
            if(!String.IsNullOrWhiteSpace(value.title))b.title=value.title;
            b.tags=value.tags;b.note=value.note;
        }
        var visible=books.Where(b=>!edits.ContainsKey(b.id)||!edits[b.id].removed).ToArray();
        summary.Text=String.Format("{0} 份馆藏　 /　{1} 份可搜正文",visible.Length,visible.Count(b=>b.searchable>0));
        var last=categories.SelectedItem;categories.Items.Clear();categories.Items.Add("全部分类");
        categories.Items.AddRange(books.Select(b=>b.category).Distinct().OrderBy(s=>s).Cast<object>().ToArray());
        categories.SelectedIndex=last!=null&&categories.Items.Contains(last)?categories.Items.IndexOf(last):0;
        var chosen=folders.SelectedItem;folders.Items.Clear();folders.Items.Add("全部文件夹");
        folders.Items.AddRange(books.Select(b=>b.folder).Distinct().OrderBy(x=>x).Cast<object>().ToArray());
        folders.SelectedIndex=chosen!=null && folders.Items.Contains(chosen)?folders.Items.IndexOf(chosen):0;
        loading=false;FindBooks();
    }
    Book Selected(){return results.SelectedItems.Count==0?null:books.FirstOrDefault(b=>b.id==results.SelectedItems[0].Name);}
    HashSet<string> BatchIds(){
        var rows=results.CheckBoxes?results.CheckedItems.Cast<ListViewItem>():results.SelectedItems.Cast<ListViewItem>();
        return new HashSet<string>(rows.Select(row=>row.Name));
    }
    void SyncActions(){
        int count=BatchIds().Count;
        bool picking=results.CheckBoxes, restoring=section.SelectedIndex==1;
        open.Enabled=!picking && !updating && results.SelectedItems.Count==1;
        ask.Enabled=open.Enabled;
        locate.Enabled=open.Enabled;
        edit.Enabled=open.Enabled && !restoring;
        remove.Enabled=!updating && !searching && (picking || restoring?count>0:results.Items.Count>0);
        remove.Text=picking?String.Format("确认移除（{0} 份）",count):restoring?"恢复到书架":"移出书架";
        if(restoring && count>1)remove.Text+=String.Format("（{0} 份）",count);
        cancelRemoval.Visible=picking;
        add.Enabled=refresh.Enabled=!updating && !picking;
    }
    void EndRemoval(){
        if(!results.CheckBoxes)return;
        foreach(var row in results.CheckedItems.Cast<ListViewItem>().ToArray())row.Checked=false;
        results.CheckBoxes=false;
        SyncActions();
    }
    void Save(Dictionary<string,EntryEdit> changes){
        var next=new Dictionary<string,EntryEdit>(edits);
        foreach(var entry in changes)next[entry.Key]=entry.Value;
        string target=Path.Combine(home,"annotations.json"),temp=target+".tmp";
        File.WriteAllText(temp,Json().Serialize(next),new UTF8Encoding(false));
        if(File.Exists(target))File.Replace(temp,target,null);else File.Move(temp,target);
        edits=next;
    }
    void Commit(Dictionary<string,EntryEdit> changes){
        try{Save(changes);EndRemoval();Reload();}
        catch(Exception ex){MessageBox.Show(this,ex.Message,"保存失败");}
    }
    void RemoveSelected(){
        if(!results.CheckBoxes && section.SelectedIndex==0){
            results.CheckBoxes=true;
            SyncActions();
            return;
        }
        var ids=BatchIds();
        if(updating || ids.Count==0)return;
        var changes=books.Where(b=>ids.Contains(b.id)).ToDictionary(b=>b.id,
            b=>new EntryEdit{title=b.title,tags=b.tags,note=b.note,category=b.category,removed=section.SelectedIndex==0});
        Commit(changes);
    }
    void EditSelected(){
        var b=Selected();if(b==null)return;
        using(var dialog=new Form{Text="编辑资料",Size=new Size(540,465),Font=Font,StartPosition=FormStartPosition.CenterParent,
            FormBorderStyle=FormBorderStyle.FixedDialog,MinimizeBox=false,MaximizeBox=false,BackColor=BackColor}){
            var fields=new[]{new TextBox{Text=b.title},new TextBox{Text=b.tags},new TextBox{Text=b.note,Multiline=true,ScrollBars=ScrollBars.Vertical}};
            string[] labels={"书名","标签","阅读笔记"};
            for(int i=0;i<3;i++){
                dialog.Controls.Add(new Label{Text=labels[i],Left=20,Top=12+63*i,AutoSize=true});
                var box=fields[i];box.SetBounds(20,34+63*i,480,i==2?114:28);dialog.Controls.Add(box);
            }
            var category=new ComboBox{Left=20,Top=308,Width=480};
            category.Items.AddRange(books.Select(x=>x.category).Distinct().OrderBy(s=>s).Cast<object>().ToArray());category.Text=b.category;
            dialog.Controls.Add(new Label{Text="馆藏分类",Left=20,Top=284,AutoSize=true});dialog.Controls.Add(category);
            var save=new Button{Text="保存",Left=414,Top=360,DialogResult=DialogResult.OK};
            var cancel=new Button{Text="取消",Left=320,Top=360,DialogResult=DialogResult.Cancel};
            dialog.Controls.AddRange(new Control[]{save,cancel});dialog.CancelButton=cancel;
            fields[0].TextChanged+=(s,e)=>save.Enabled=!String.IsNullOrWhiteSpace(fields[0].Text);
            if(dialog.ShowDialog(this)==DialogResult.OK)Commit(new Dictionary<string,EntryEdit>{{b.id,new EntryEdit{title=fields[0].Text.Trim(),tags=fields[1].Text.Trim(),note=fields[2].Text.Trim(),category=String.IsNullOrWhiteSpace(category.Text)?"待分类":category.Text.Trim()}}});
        }
    }
    void AddBooks(){
        using(var picker=new OpenFileDialog{Title="添加到书架",Filter="PDF 文档 (*.pdf)|*.pdf",Multiselect=true})
            if(picker.ShowDialog(this)==DialogResult.OK)UpdateBooks(picker.FileNames);
    }
    static string[] Pages(string dir, Book b){
        string js=File.ReadAllText(Path.Combine(dir,"index",b.id+".js"));
        string data=js.Split('"')[3];
        using(var gz=new GZipStream(new MemoryStream(Convert.FromBase64String(data)),CompressionMode.Decompress))
        using(var reader=new StreamReader(gz))return Json().Deserialize<string[]>(reader.ReadToEnd());
    }
    static List<ListViewItem> Matches(string dir,Book[] subset,string q,bool full,CancellationToken token,System.Collections.Concurrent.ConcurrentDictionary<string,string[]> cache=null){
        var rows=new List<ListViewItem>();
        foreach(var b in subset){
            token.ThrowIfCancellationRequested();int hits=0;
            if(full && q.Length>0 && b.searchable>0){
                var pages=cache==null?Pages(dir,b):cache.GetOrAdd(b.id,id=>Pages(dir,b).Select(line=>gaps.Replace(line,"")).ToArray());
                for(int p=0;p<pages.Length && hits<3;p++){
                    token.ThrowIfCancellationRequested();string line=cache==null?gaps.Replace(pages[p],""):pages[p];
                    int at=line.IndexOf(q,StringComparison.OrdinalIgnoreCase);
                    if(at<0)continue;
                    int start=Math.Max(0,at-24);
                    rows.Add(Row(b,p+1,line.Substring(start,Math.Min(line.Length-start,q.Length+82))));hits++;
                }
            }
            if(hits==0 && new[]{b.title,b.tags,b.note}.Any(v=>(v??"").IndexOf(q,StringComparison.OrdinalIgnoreCase)>=0))
                rows.Add(Row(b,0,b.status));
        }
        return rows;
    }
    static ListViewItem Row(Book b,int page,string excerpt){
        return new ListViewItem(new[]{b.title,page==0?"":page.ToString(),excerpt,b.folder=="."?"桌面根目录":b.folder,b.tags??""})
            { Name=b.id, Tag=b.url+(page==0?"":"#page="+page) };
    }
    async void FindBooks(){
        if(loading || updating || books==null)return;
        EndRemoval();
        searching=true;SyncActions();
        if(search!=null)search.Cancel();
        var job=new CancellationTokenSource();search=job;
        string q=query.Text.Trim();bool full=scope.SelectedIndex==0;
        bool removed=section.SelectedIndex==1;
        var subset=books.Where(b=>(edits.ContainsKey(b.id)&&edits[b.id].removed)==removed)
            .Where(b=>categories.SelectedIndex==0 || b.category==(string)categories.SelectedItem)
            .Where(b=>folders.SelectedIndex==0 || b.folder==(string)folders.SelectedItem).OrderBy(b=>b.title).ToArray();
        status.Text="正在查找…";
        try{
            var rows=(full && q.Length>0)
                ? await Task.Run(()=>Matches(home,subset,q,true,job.Token,textCache))
                : Matches(home,subset,q,false,job.Token);
            if(job.IsCancellationRequested)return;
            results.BeginUpdate();results.Items.Clear();results.Items.AddRange(rows.ToArray());results.EndUpdate();
            SyncActions();
            status.Text=String.Format("{0}　 /　{1} 份资料　·　{2}",removed?"已移除":"馆藏",rows.Select(r=>r.Name).Distinct().Count(),removed?"按住 Ctrl 点选可批量恢复":"双击书名阅读");
        }catch(OperationCanceledException){}catch(Exception ex){if(!job.IsCancellationRequested)status.Text="检索失败："+ex.Message;}
        finally{if(search==job){searching=false;SyncActions();}}
    }
    void OpenSelected(){
        if(results.CheckBoxes || results.SelectedItems.Count!=1)return;
        try{
            var uri=new Uri((string)results.SelectedItems[0].Tag);
            if(!File.Exists(uri.LocalPath)){MessageBox.Show("原文件已移动。请点击「重新定位」选择新位置，或扫描更新以寻找桌面内的同一文件。");return;}
            string edge=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),"Microsoft","Edge","Application","msedge.exe");
            if(File.Exists(edge))Process.Start(edge,"\""+uri.AbsoluteUri+"\"");
            else Process.Start(new ProcessStartInfo(uri.LocalPath){UseShellExecute=true});
        }catch(Exception ex){MessageBox.Show(ex.Message);}
    }
    async void UpdateBooks(string[] paths,string relocateId=null,string replacement=null){
        if(updating)return;updating=true;SyncActions();if(search!=null)search.Cancel();
        status.Text=paths==null?"正在扫描桌面和已添加的资料…":"正在添加并提取 PDF 正文…";
        string request=Path.Combine(home,"import.json");
        try{
            await Task.Run(()=>{
                if(paths!=null)File.WriteAllText(request,Json().Serialize(paths));
                string arguments=relocateId!=null?" --relocate \""+relocateId+"\" \""+replacement+"\"":paths==null?"":" --add \""+request+"\"";
                var start=new ProcessStartInfo(Path.Combine(home,"runtime","python.exe"),"-I -B \""+Path.Combine(home,"shelf-indexer.py")+"\""+arguments)
                    {WorkingDirectory=home,UseShellExecute=false,CreateNoWindow=true,RedirectStandardError=true};
                using(var process=Process.Start(start)){
                    string error=process.StandardError.ReadToEnd();process.WaitForExit();
                    if(process.ExitCode!=0)throw new Exception(error);
                }
            });
            if(paths!=null){
                var urls=new HashSet<string>(paths.Select(p=>new Uri(p).AbsoluteUri),StringComparer.OrdinalIgnoreCase);
                var restore=new Dictionary<string,EntryEdit>();
                foreach(var b in books.Where(b=>urls.Contains(new Uri(b.url).AbsoluteUri) && edits.ContainsKey(b.id) && edits[b.id].removed))
                    restore[b.id]=new EntryEdit{title=b.title,tags=b.tags,note=b.note,category=b.category};
                if(restore.Count>0)Save(restore);
                section.SelectedIndex=0;folders.SelectedIndex=0;categories.SelectedIndex=0;query.Clear();
            }
            textCache.Clear();updating=false;Reload();
        }catch(Exception ex){status.Text="更新失败";MessageBox.Show(ex.Message);}
        finally{updating=false;SyncActions();if(File.Exists(request))File.Delete(request);}
    }
    [STAThread] public static int Main(string[] args){
        bool check=args.Length==2 && args[0]=="--verify";
        string parent=check?args[1]:Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"LocalPdfShelf");
        string dir=Path.Combine(parent,"v1");
        try{
            using(var mutex=new Mutex(false,check?null:"Local\\PdfShelfDesktopV1")){
                try{if(!mutex.WaitOne(0)){if(!check)MessageBox.Show("书架已打开。");return 0;}}catch(AbandonedMutexException){}
                if(!Directory.Exists(dir)){
                    Directory.CreateDirectory(parent);string stage=dir+"-"+Guid.NewGuid().ToString("N");
                    Directory.CreateDirectory(stage);
                    using(var stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("payload"))
                    using(var zip=new ZipArchive(stream))zip.ExtractToDirectory(stage);
                    Directory.Move(stage,dir);
                }
                using(var script=Assembly.GetExecutingAssembly().GetManifestResourceStream("indexer"))
                using(var dest=File.Create(Path.Combine(dir,"shelf-indexer.py")))script.CopyTo(dest);
                if(check){
                    var catalog=File.ReadAllText(Path.Combine(dir,"index","catalog.js")).Substring(13);
                    var entries=Json().Deserialize<Book[]>(catalog);
                    if(entries.Length==0)return 0;
                    var rows=Matches(dir,entries,"历史",true,CancellationToken.None);
                    return rows.Any(r=>((string)r.Tag).Contains("#page="))?0:2;
                }
                Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new Shelf(dir));
            }
            return 0;
        }catch(Exception ex){if(!check)MessageBox.Show(ex.Message,"我的书架");return 1;}
    }
}
