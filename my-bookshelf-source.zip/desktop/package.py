"""Build the personal Windows x64 bookshelf with its offline index and Python runtime."""
from pathlib import Path
import os
import argparse
import subprocess
import sys
import tempfile
import zipfile

src = Path(__file__).resolve().parent
shelf = src.parent
runtime = Path(sys.base_prefix)
compiler = Path(os.environ["WINDIR"]) / "Microsoft.NET/Framework64/v4.0.30319/csc.exe"
parser = argparse.ArgumentParser()
parser.add_argument("--share", action="store_true", help="Build a distributable ZIP with an empty library")
parser.add_argument("output", nargs="?", type=Path)
args = parser.parse_args()
out = (args.output or (shelf / ("我的书架-Windows-x64.zip" if args.share else "我的书架.exe"))).resolve()
with tempfile.TemporaryDirectory(dir=shelf) as tmp:
    payload = Path(tmp) / "payload.zip"
    with zipfile.ZipFile(payload, "w", zipfile.ZIP_DEFLATED, compresslevel=4) as z:
        z.write(shelf / "build.py", "build.py")
        if args.share:
            z.writestr("index/catalog.js", "window.books=[]")
        else:
            for f in (shelf / "index").glob("*.js"):
                z.write(f, "index/" + f.name)
        def include(f):
            z.write(f, "runtime/" + f.relative_to(runtime).as_posix())
        for f in [runtime / "python.exe", runtime / "LICENSE.txt", *runtime.glob("*.dll")]:
            include(f)
        for f in (runtime / "DLLs").iterdir():
            if f.is_file() and f.suffix.lower() in {".dll", ".pyd"}:
                include(f)
        for f in (runtime / "Lib").rglob("*"):
            parts = f.relative_to(runtime / "Lib").parts
            if not f.is_file() or any(p in {"__pycache__", "test", "tests"} for p in parts):
                continue
            if parts[0] == "site-packages":
                if len(parts) > 1 and parts[1].startswith("pypdfium2"):
                    include(f)
            elif f.suffix == ".py" and parts[0] not in {"idlelib", "tkinter", "ensurepip"}:
                include(f)
    categories = src / "categories.json"
    if args.share:
        categories = Path(tmp) / "categories.json"
        categories.write_text("{}", encoding="utf8")
    compiled = Path(tmp) / ("我的书架.exe" if args.share else out.name)
    subprocess.run([str(compiler), "/nologo", "/codepage:65001", "/target:winexe", "/platform:x64",
                    "/optimize+", "/r:System.Windows.Forms.dll", "/r:System.Drawing.dll",
                    "/win32icon:" + str(src / "bookshelf.ico"),
                    "/r:System.IO.Compression.dll", "/r:System.IO.Compression.FileSystem.dll",
                    "/r:System.Web.Extensions.dll", "/resource:" + str(payload) + ",payload",
                    "/resource:" + str(shelf / "build.py") + ",indexer",
                    "/resource:" + str(categories) + ",categories",
                    "/r:System.Net.Http.dll", "/r:System.Security.dll", "/out:" + str(compiled),
                    str(src / "Shelf.cs"), str(src / "ReadingQuestion.cs")], check=True)
    if args.share:
        archive = Path(tmp) / "release.zip"
        with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as z:
            z.write(compiled, compiled.name)
            z.writestr("使用说明.txt", """我的书架 · Windows x64

解压全部文件，双击「我的书架.exe」。首次启动会展开内置运行环境，请稍候。

添加资料：点击「＋ 添加 PDF」选择自己的文件，或点击「扫描更新」收录桌面及子文件夹中的 PDF。
搜索与阅读：输入书名或正文关键词，双击结果打开 PDF。扫描件需要先做 OCR 才能搜正文。
分类与笔记：选中资料，点击「编辑资料」填写分类、标签和阅读笔记。
移除与恢复：点击「移出书架」后勾选并确认。可在「已移除」恢复资料，PDF 原件留在原处。
整书问答：选中一本书，点击「问 DeepSeek」，输入自己的 API Key。发送后，所选范围内的正文与问题会提交到 DeepSeek，按该账户的 API 使用量计费。

书架将索引和笔记存放在当前 Windows 用户的 %LOCALAPPDATA%\\LocalPdfShelf\\v1 文件夹。PDF 从原路径读取。
""".replace("\n","\r\n").encode("utf-8-sig"))
        archive.replace(out)
    else:
        compiled.replace(out)
    print(out.stat().st_size)
