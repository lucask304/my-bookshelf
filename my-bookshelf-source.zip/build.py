"""Index the user's desktop PDFs for a standalone, offline browser bookshelf."""
import base64
import ctypes
import gzip
import hashlib
import json
import os
import sys
from pathlib import Path
from urllib.parse import urlparse, unquote
import uuid

import pypdfium2 as pdfium

HERE = Path(__file__).resolve().parent
DATA = HERE / "index"
DATA.mkdir(exist_ok=True)


def write_atomic(path, value):
    tmp = path.with_suffix(".tmp")
    tmp.write_text(value, encoding="utf-8")
    tmp.replace(path)


def extract(path):
    pages = []
    failures = 0
    doc = pdfium.PdfDocument(str(path))
    try:
        for page in doc:
            try:
                layer = page.get_textpage()
                try:
                    pages.append(" ".join(layer.get_text_bounded().split()))
                finally:
                    layer.close()
            except Exception:
                failures += 1
                pages.append("")
            finally:
                page.close()
    finally:
        doc.close()
    return pages, failures


def desktop():
    buf = ctypes.create_unicode_buffer(32768)
    if ctypes.windll.shell32.SHGetFolderPathW(None, 16, None, 0, buf) == 0 and buf.value:
        return Path(buf.value)
    return Path.home() / "Desktop"


def main():
    adding = sys.argv[1:2] == ["--add"]
    relocating = sys.argv[1:2] == ["--relocate"]
    fingerprinting = sys.argv[1:2] == ["--fingerprint"]
    root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 and not any((adding, relocating, fingerprinting)) else desktop()
    if not root.is_dir():
        raise SystemExit("Source directory unavailable")
    manifest = DATA / "catalog.js"
    prefix = "window.books="
    old = json.loads(manifest.read_text("utf-8")[len(prefix):]) if manifest.exists() else []
    def location(book):
        return Path(unquote(urlparse(book["url"]).path).lstrip("/"))
    def digest(path):
        with path.open("rb") as stream:
            return hashlib.file_digest(stream, "sha256").hexdigest()
    for book in old:
        path = location(book)
        if not book.get("sha256") and path.is_file():
            book["sha256"] = digest(path)
    if fingerprinting:
        write_atomic(manifest, prefix + json.dumps(old, ensure_ascii=False))
        return
    target = None
    if relocating:
        target = next(b for b in old if b["id"] == sys.argv[2])
        replacement = Path(sys.argv[3]).resolve()
        if replacement.suffix.lower() != ".pdf" or not replacement.is_file():
            raise ValueError("请选择可读取的 PDF")
        if any(b["id"] != target["id"] and b["url"].casefold() == replacement.as_uri().casefold() for b in old):
            raise ValueError("此文件已属于另一条馆藏，请选择该资料的新文件位置")
        if target.get("sha256") and digest(replacement) != target["sha256"]:
            raise ValueError("所选文件与原 PDF 内容不同，请选择原文件")
    cache = {b["id"]: b for b in old}
    existing = {b["url"].casefold(): b for b in old}
    if relocating:
        paths = [replacement]
        indexed = existing.copy()
    elif adding:
        paths = [Path(p).resolve() for p in json.loads(Path(sys.argv[2]).read_text("utf-8-sig"))]
        if any(not p.is_file() or p.suffix.lower() != ".pdf" for p in paths):
            raise ValueError("请选择可读取的 PDF 文件")
        indexed = existing.copy()
    else:
        paths = sorted(root.rglob("*.[pP][dD][fF]"))
        paths.extend(Path(b["external"]) for b in old if b.get("external"))
        indexed = existing.copy()
    claimed = set()
    missing = [b for b in old if not location(b).is_file()]
    for path in dict.fromkeys(paths):
        if not path.is_file():
            if path.as_uri().casefold() in existing and existing[path.as_uri().casefold()].get("external"):
                indexed[path.as_uri().casefold()] = existing[path.as_uri().casefold()]
            continue
        url_key = path.as_uri().casefold()
        previous = target if relocating else existing.get(url_key)
        content_hash = digest(path)
        if previous is None:
            candidates = [b for b in missing if b.get("sha256") == content_hash and b["id"] not in claimed]
            if len(candidates) == 1:
                previous = candidates[0]
        key = previous["id"] if previous else uuid.uuid4().hex
        claimed.add(key)
        if previous:
            indexed.pop(previous["url"].casefold(), None)
        store = DATA / (key + ".js")
        stat = path.stat()
        stamp = [stat.st_size, stat.st_mtime_ns]
        local = path.is_relative_to(root)
        book = dict(id=key, title=path.stem, folder=str(path.parent.relative_to(root) if local else path.parent),
                    url=path.as_uri(), stamp=stamp, pages=0, searchable=0, status="读取失败")
        book["sha256"] = content_hash
        if previous:
            book["title"] = previous["title"]
        if not local:
            book["external"] = str(path)
        if previous and previous.get("sha256") == content_hash and store.exists() and previous["status"] != "读取失败":
            book.update({k: previous[k] for k in ("pages", "searchable", "status")})
            indexed[url_key] = book
            continue
        try:
            pages, failures = extract(path)
            total = len(pages)
            readable = sum(bool(p) for p in pages)
            status = ("部分页面读取失败" if failures else "可搜正文" if readable else "无可检索文字")
            book.update(pages=total, searchable=readable, status=status)
            packed = gzip.compress(json.dumps(pages, ensure_ascii=False).encode(), compresslevel=3)
            payload = base64.b64encode(packed).decode()
            write_atomic(store, f'window.receiveBook("{key}","{payload}")')
        except Exception as exc:
            print(f"Skipped text {key}: {type(exc).__name__}", flush=True)
        indexed[url_key] = book
    books = list(indexed.values())
    write_atomic(manifest, prefix + json.dumps(books, ensure_ascii=False))
    keep = {b["id"] for b in books}
    for stale in DATA.glob("*.js"):
        if stale != manifest and stale.stem not in keep:
            stale.unlink()
    print(f"Books: {len(books)}, searchable: {sum(bool(b['searchable']) for b in books)}, "
          f"pages with text: {sum(b['searchable'] for b in books)}", flush=True)


if __name__ == "__main__":
    main()
